#!/usr/bin/env bash

docker run -e PROBLEM_NAME="sample_problem" -v $(pwd):/workspace abhinav3295/devenv